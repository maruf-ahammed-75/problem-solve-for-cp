#include <bits/stdc++.h>
#define ll long long
#define i128 __int128_t
using namespace std;
int32_t main() {
    i128 x = 1;
    int y = (int)(x+1);
    cout<<y<<endl;
    return 0;
}
// not all compiler support i128
// i128 can be store not print 
// range -2^127 to 2^127-1 